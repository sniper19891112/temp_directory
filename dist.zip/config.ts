export const VITE_BASE_URL = "http://27.126.187.127:81/api";
export const VITE_HOST_URL = "http://27.126.187.128:8080"
export const VITE_SOCKET_URL = "http://27.126.187.127"
export const VITE_FILE_BASE_URL = "http://27.126.187.127:81"
export const VITE_SERVICE_URL = "https://wap.hg909c.com"
export const VITE_LY_PAY_URL = "http://api2.spellsbet.com/v1/cash"