const s="/assets/avatar-ec273e0b.png";export{s as _};
