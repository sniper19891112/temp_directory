const s="/assets/green-a95a3b90.png";export{s as _};
