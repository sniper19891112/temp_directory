const e="/assets/icon-circle-active-red-8774ebf6.png";export{e as _};
