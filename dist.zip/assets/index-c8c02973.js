import{s as t}from"./Dialog-358063df.js";import{w as o}from"./auth-33b7cde7.js";const i=o(t);export{i as D};
