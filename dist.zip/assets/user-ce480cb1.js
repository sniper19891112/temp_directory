const s="/assets/user-56b8e8a8.png";export{s as _};
