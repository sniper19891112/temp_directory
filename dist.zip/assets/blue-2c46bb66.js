const s="/assets/red-9076eb28.png",t="/assets/blue-24005d16.png";export{s as _,t as a};
