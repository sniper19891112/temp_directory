const s="/assets/looding-9da86c84.png";export{s as _};
